# Experimento especial v1.5 — cobertura de 95%

Arquivos principais:
- `experimento_especial_cobertura_95_v1_5.ipynb`: notebook independente Colab (exemplos autossuficientes + painel completo).
- `dados/rodadas_cobertura_por_candidato_v1_5.csv.gz`: resultados precomputados, 3.000 repetições de cinco modelos em dois cenários (seis candidatos).
- `gerar_experimento_v15.py`: geração reproduzível dos resultados a partir das três camadas de 1 milhão de eleitores v0.7, v0.8 e v1.1; requer numpy, pandas e scipy.
- `saida/resumo_cobertura_v1_5.csv`: métricas agregadas por cenário/método/candidato.
- `relatorio_validacao_v1_5.md`: desenho, hipóteses, ressalvas e resultados.
- `grafico_cobertura_A_neutra.png` e `grafico_cobertura_A_seletiva.png`: ilustrações diretamente dos dados.

O arquivo `02_incerteza_e_testes_de_hipotese_revisado_pesquisas_2026_v1_5.ipynb` foi preparado separadamente e inclui cinco células novas após o experimento inicial de repetição de pesquisas. Recomenda-se copiar as células ou substituir a variante local no repositório após revisão editorial. O GitHub não foi alterado.

Para executar o **painel com dados completos** no Colab, envie o CSV compactado no painel de arquivos (ou coloque-o em `unidade_05/dados/` junto ao notebook principal) e execute as células. Não é necessário carregar os microdados completos dos 1 milhão de eleitores.

**Aviso:** não são reproduções de levantamentos reais; os pseudo-intervalos dos modelos por cotas ou digitais não possuem cobertura de 95% garantida.
