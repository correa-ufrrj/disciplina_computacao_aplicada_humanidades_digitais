#!/usr/bin/env python3
"""Experimento didático repetível de cobertura sobre população sintética v0.7/v0.8/v1.1.
Não reconstrução de levantamentos nem cópia integral dos procedimentos da v1.4.
Amostragem AAS e PPSWR possuem desenho definido; outros intervalos são diagnósticos.
"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import norm,t

LABELS=['A','B','C','OUTRA','INDECISO','BRANCO_NULO']
METHODS=['aleatoria_simples','municipal_probabilistico','domiciliar_seletivo',
         'fluxo_cotas_aproximado','digital_posestratificado']

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()

def setup(v07,v08,v11):
 d=pd.read_csv(v07,usecols=['eleitor_id','uf','sexo_registrado','idade_pnad_doador','internet_uso_3m_pnad_tic_2025_imputado'])
 b=pd.read_csv(v08,usecols=['eleitor_id','preferencia_sincera_ficticia','prob_contato_domiciliar_hipotetica','prob_aceite_presencial_hipotetica','propensao_circulacao_hipotetica','prob_aceite_digital_hipotetica'])
 m=pd.read_csv(v11)
 assert len(d)==len(b)==len(m)==1_000_000
 assert d.eleitor_id.equals(b.eleitor_id) and d.eleitor_id.equals(m.eleitor_id)
 assert d.uf.equals(m.uf)
 cats=pd.Categorical(b['preferencia_sincera_ficticia'],categories=LABELS).codes
 assert (cats>=0).all()
 cities,city=np.unique(m.municipio_id_tse_atribuido.to_numpy(),return_inverse=True)
 NC=len(cities); C=len(LABELS)
 truth=np.bincount(cats,minlength=C)/len(d)
 city_sizes=np.bincount(city,minlength=NC)
 city_w=city_sizes/len(d)
 assert NC==5571 and abs(truth[0]-0.419945)<1e-8
 sex=pd.Categorical(d.sexo_registrado,categories=['MASCULINO','FEMININO','NÃO INFORMADO']).codes
 age=np.digitize(d.idade_pnad_doador.to_numpy(),[25,40,60]); q=sex*4+age
 assert np.all(sex>=0) and np.all((q>=0)&(q<12))
 q_target=np.bincount(q,minlength=12)/len(d)
 home=(b.prob_contato_domiciliar_hipotetica*b.prob_aceite_presencial_hipotetica).to_numpy()
 flow=(b.propensao_circulacao_hipotetica*b.prob_aceite_presencial_hipotetica).to_numpy()
 digital=b.prob_aceite_digital_hipotetica.to_numpy()*d.internet_uso_3m_pnad_tic_2025_imputado.to_numpy().astype(float)
 assert np.all(np.isfinite(home)) and np.all(np.isfinite(flow)) and np.all(np.isfinite(digital))
 return dict(cats=cats,city=city,n_city=NC,C=C,truth=truth,city_w=city_w,city_sizes=city_sizes,
             q=q,q_target=q_target,home=home,flow=flow,digital=digital,
             N=len(d),sha={f.name:sha(f) for f in [v07,v08,v11]})

def aggregate(d, factor):
 """Perfis fixos antes do Monte Carlo; o fator é hipotético e discrimina A."""
 NC=d['n_city'];C=d['C'];cat=d['cats'];city=d['city'];q=d['q']
 tilt=np.where(cat==0,factor,1.0)
 city_count=np.bincount(city*C+cat,minlength=NC*C).reshape(NC,C)
 pm_city=city_count / d['city_sizes'][:,None]
 w_home=np.bincount(city*C+cat,weights=d['home']*tilt,minlength=NC*C).reshape(NC,C)
 pm_home=w_home / w_home.sum(axis=1,keepdims=True)
 assert np.isfinite(pm_home).all()
 # fluxos e cotas em classes sexo cadastral x idade; margens nacionais exatas.
 w_flow=np.bincount(q*C+cat,weights=d['flow']*tilt,minlength=12*C).reshape(12,C)
 p_flow=np.divide(w_flow,w_flow.sum(axis=1,keepdims=True),out=np.zeros_like(w_flow),where=w_flow.sum(axis=1,keepdims=True)>0)
 # Distribuição de recrutados digitais por cota (usa Internet + resposta fictícia).
 w_dig=np.bincount(q*C+cat,weights=d['digital']*tilt,minlength=12*C).reshape(12,C)
 assert np.all(w_dig.sum(axis=1)[d['q_target']>0]>0)
 p_dig=(w_dig/w_dig.sum())
 return dict(pm_city=pm_city,pm_home=pm_home,p_flow=p_flow,p_dig=p_dig,truth=d['truth'])

def wilson(count,n):
 """IC Wilson de 95% para cada candidato marginal binário."""
 p=np.asarray(count)/n; z=norm.ppf(.975)
 denom=1+z*z/n
 mid=(p+z*z/(2*n))/denom
 half=z/denom*np.sqrt(p*(1-p)/n+z*z/(4*n*n))
 return mid-half,mid+half

def evaluate(method, counts,truth,lo,hi,fac,n,scenario,extra=None):
 estimate=counts/n if method in ('aleatoria_simples','fluxo_cotas_aproximado') else counts
 covers=(lo<=truth)&(truth<=hi)
 rows=[]
 R=len(estimate)
 for c,label in enumerate(LABELS):
  part=pd.DataFrame({'cenario_resposta_A':fac,'rep':np.arange(1,R+1),
                     'metodo':method,'candidato':label,'verdade':truth[c],
                     'estimativa':estimate[:,c], 'limite_inferior':lo[:,c],
                     'limite_superior':hi[:,c], 'cobre':covers[:,c].astype('int8'),
                     'tipo_intervalo':('probabilistico' if method in ('aleatoria_simples','municipal_probabilistico') else 'pseudo_intervalo')})
  rows.append(part)
 return pd.concat(rows,ignore_index=True)

def draw_city(rng,p_city,profiles,reps,n=2000,k=100,m=20):
 """PPSWR municipal e multinomial dentro de cada sorteio de município (com reposição)."""
 assert n==k*m
 out=[];lower=[];upper=[]
 z=t.ppf(.975,k-1)
 for off in range(0,reps,250):
  r=min(250,reps-off)
  loc=rng.choice(len(p_city),size=(r,k),replace=True,p=p_city)
  counts=rng.multinomial(m, profiles[loc])  # r x 100 x 6
  frac=counts/m
  est=frac.mean(axis=1)
  se=frac.std(axis=1,ddof=1)/np.sqrt(k)
  # Interpretação: intervalo de conglomerados justificado somente para o PPSWR neutro.
  out.append(est);lower.append(np.maximum(0,est-z*se));upper.append(np.minimum(1,est+z*se))
 return np.concatenate(out),np.concatenate(lower),np.concatenate(upper)

def main(args):
 d=setup(args.v07,args.v08,args.v11)
 out=args.out;out.mkdir(parents=True,exist_ok=True)
 rng=np.random.default_rng(args.seed)
 R=args.reps;n=args.n;truth=d['truth']
 all_rows=[]
 for factor in [1.,.55]:
  p=aggregate(d,factor)
  # Controle AAS multinomial i.i.d. (amostragem com reposição).
  cnt=rng.multinomial(n,truth,size=R)
  lo,hi=wilson(cnt,n)
  all_rows.append(evaluate('aleatoria_simples',cnt,truth,lo,hi,factor,n,scenario=None))
  # Controle PPSWR em duas etapas, variância por conglomerados.
  est,lo,hi=draw_city(rng,d['city_w'],p['pm_city'],R,n=n)
  all_rows.append(evaluate('municipal_probabilistico',est,truth,lo,hi,factor,n,scenario=None))  # evaluator divide by n unless handled below
  # Domiciliar: seleção ajustada por propensões reais SINTÉTICAS; resposta de A reduzida.
  est,lo,hi=draw_city(rng,d['city_w'],p['pm_home'],R,n=n)
  all_rows.append(evaluate('domiciliar_seletivo',est,truth,lo,hi,factor,n,scenario=None))
  # Fluxo com cotas: APROXIMAÇÃO nacional marginal (NÃO modelo territorial completo v1.4).
  nq=np.floor(n*d['q_target']).astype(int)
  diff=n-nq.sum(); frac=n*d['q_target']-nq
  nq[np.argsort(-frac)[:diff]]+=1
  cq=np.zeros((R,d['C']),dtype=int)
  for j,num in enumerate(nq):
   if num: cq+=rng.multinomial(int(num),p['p_flow'][j],size=R)
  lo,hi=wilson(cq,n)
  all_rows.append(evaluate('fluxo_cotas_aproximado',cq,truth,lo,hi,factor,n,scenario=None))
  # Digital: sem quadro probabilístico, pós-estratificação por sexo cadastral x idade.
  # Recrutamos em cada estrato com contagem aleatória; estratos ausentes são raros,
  # mas tornamos explícita a ocorrência e um pseudo-IC sem garantia de 95%.
  ct=rng.multinomial(n,p['p_dig'].ravel(),size=R).reshape(R,12,d['C'])
  nq_dig=ct.sum(axis=2)
  # Corrigir apenas margens demográficas com suporte; negligencia dependências UF etc.
  supported=nq_dig>0
  w=np.where(supported,d['q_target'][None,:],0.)
  w/=w.sum(axis=1,keepdims=True)
  frac=np.divide(ct,nq_dig[:,:,None],out=np.zeros_like(ct,dtype=float),where=nq_dig[:,:,None]>0)
  est=(frac*w[:,:,None]).sum(axis=1)
  # Kish aproximado: pesos pós-estrato por pessoa; não representa variância do modelo digital.
  neff=np.divide(1.,np.sum(w**2/np.maximum(nq_dig,1),axis=1))
  z=norm.ppf(.975)
  half=z*np.sqrt(np.maximum(est*(1-est),0)/neff[:,None])
  lo=np.maximum(0,est-half);hi=np.minimum(1,est+half)
  all_rows.append(evaluate('digital_posestratificado',est,truth,lo,hi,factor,n,scenario=None))
  print('Executado fator A:',factor,flush=True)
 rounds=pd.concat(all_rows,ignore_index=True)
 # as duas etapas de draw_city retornam ESTIMATIVAS, nao contagens!
 assert np.all((rounds.estimativa>=0)&(rounds.estimativa<=1)), 'Escala das proporcoes invalida'
 assert len(rounds)==2*5*len(LABELS)*R
 rounds['cobertura_acumulada']=rounds.groupby(['cenario_resposta_A','metodo','candidato'],sort=False)['cobre'].transform(lambda x:x.expanding().mean())
 rounds_path=out/'rodadas_cobertura_por_candidato_v1_5.csv.gz'
 rounds.to_csv(rounds_path,index=False,compression={'method':'gzip','compresslevel':5,'mtime':0},float_format='%.9f')
 summ=(rounds.groupby(['cenario_resposta_A','metodo','candidato','tipo_intervalo'])
       .agg(repeticoes=('rep','size'),verdade=('verdade','first'),media_estimada=('estimativa','mean'),
            vies_pp=('estimativa',lambda x:100*(x.mean()-float(rounds.loc[x.index[0],'verdade']))),
            cobertura=('cobre','mean'),dp_pp=('estimativa',lambda x:100*x.std(ddof=1)))
       .reset_index())
 summ.to_csv(out/'resumo_cobertura_v1_5.csv',index=False,float_format='%.9f')
 manifest=dict(versao='1.5',objetivo='Cobertura acumulada por candidato e procedimento',R=R,n=n,seed=args.seed,
               verdade={a:float(v) for a,v in zip(LABELS,truth)},fontes_entrada_sha256=d['sha'],
               saidas_sha256={i.name:sha(i) for i in out.glob('*.csv*')},
               limites=['Metodos sao emuladores didaticos, nao institutos reais.',
                        'AAS com reposição; amostragem de municipios PPSWR, dentro multinomial com reposicao.',
                        'Fluxo com cotas simulado por margens nacionais, nao algoritmos espaciais completos v1.4.',
                        'Calibracao digital restrita a sexo x idade; pseudo-IC sem garantia nominal.'])
 (out/'manifesto_v1_5.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 print(summ.query('candidato in ["A", "B", "C"]').round(4).to_string(index=False),flush=True)
 return rounds,summ

if __name__=='__main__':
 ap=argparse.ArgumentParser()
 for name in ['v07','v08','v11','out']:ap.add_argument('--'+name,type=Path,required=True)
 ap.add_argument('--reps',type=int,default=3000);ap.add_argument('--n',type=int,default=2000)
 ap.add_argument('--seed',type=int,default=202610160915)
 args=ap.parse_args()
 main(args)
