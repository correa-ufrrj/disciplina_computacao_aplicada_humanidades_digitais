# Relatório de validação — experimento v1.5

## Objetivo

Observar, por candidato e conforme cresce o número de pesquisas repetidas, a **cobertura acumulada dos intervalos de 95%**. A convergência dessa proporção é para a *cobertura efetiva* do procedimento — aproximadamente 95% quando o intervalo é apropriado e as hipóteses se sustentam; possivelmente muito menos em levantamentos sujeitos a seletividade.

## Escopo e fontes

- Mesma população fixa de 1 milhão (camadas v0.7, v0.8 e municipal v1.1), verificadas por IDs alinhados.
- Seis categorias eleitorais sintéticas: A=41,9945%, B=38,0190%, C=12,0219%, OUTRA=2,9968%, INDECISO=2,9766%, BRANCO_NULO=1,9912%.
- 3.000 rodadas para cada um de cinco procedimentos e dois cenários de participação: **30.000 pesquisas**, cada qual com 2.000 observações. Cada uma gera seis intervalos: **180.000 avaliações de cobertura**.
- Recrutamento neutro (fator A=1,00) e seletividade hipotética (fator A=0,55). A aleatória simples e o PPSWR municipal são controles e permanecem sem seletividade.

## Modelo por procedimento

1. **Aleatória simples**: sorteios independentes, com reposição, da distribuição marginal verdadeira. IC Wilson por candidato. Controle probabilístico.
2. **Municipal probabilístico**: 100 sorteios de municípios PPSWR conforme tamanho do eleitorado sintético e 20 respostas multinomiais por sorteio municipal; intervalo t baseado nas 100 médias dos conglomerados. Controle probabilístico, distinto da rotina exata anterior.
3. **Domiciliar hipotético**: mesmos 100 sorteios municipais, recrutamento proporcional à propensão de contato/aceite da camada v0.8; redução hipotética da aceitação de A. Intervalo entre conglomerados é diagnóstico, **sem garantia de cobertura populacional**.
4. **Fluxo com cotas**: emulador agregado por 12 células (sexo cadastral × idade), com cotas nacionais e propensão v0.8. Não incorpora a alocação espacial local corrigida na v1.4; usa pseudo-IC Wilson.
5. **Digital**: candidatos recrutados conforme conectividade e propensão sintética; pós-estratificação por 12 células sexo × idade; pseudo-IC normal com tamanho efetivo de Kish. Não incorpora UF nem reproduz a calibração integral da v1.4.

**Os procedimentos são didáticos e não replicam as metodologias efetivas de Quaest, Datafolha ou AtlasIntel.** Os três métodos não probabilísticos não possuem justificativa para uma cobertura nominal de 95%.

## Coberturas observadas (3.000 pesquisas por célula)

| Cenário e modelo | A | B | C |
|---|---:|---:|---:|
| Neutro — aleatória simples | 95.53% | 95.43% | 94.87% |
| Neutro — municipal probabilístico | 95.17% | 94.83% | 95.67% |
| Seletivo — domiciliar | 0.00% | 0.00% | 10.17% |
| Seletivo — fluxo com cotas | 0.00% | 0.00% | 3.53% |
| Seletivo — digital | 0.00% | 0.00% | 5.67% |

## Interpretação

A frequência de cobertura observada em R repetições tem erro de Monte Carlo. Se a cobertura verdadeira fosse exatamente 0,95, então após 3.000 pesquisas seu desvio-padrão seria aproximadamente 0,40 ponto percentual; uma faixa aproximada de 95% seria 95 ± 0,78 p.p. Portanto convergência **não significa chegar exatamente ou monotonamente a 95%**.

A média cumulativa da estimativa tende à média da distribuição geradora das respostas. Se essa distribuição é enviesada, aumentar repetições **não remove** o viés. Os resultados de C e das categorias menores devem ser examinados individualmente e intervalos dos seis candidatos não têm, em conjunto, 95% de cobertura simultânea.

## Validações

- 180.000 registros, sem faltantes, 2.000 entrevistas por pesquisa e 3.000 rodadas por combinação.
- Preferências de seis categorias somam 100% em cada repetição; limites do IC respeitam 0 a 100%.
- Frequências de cobertura acumulada calculadas por candidato, método e cenário e verificadas contra a média final.
- Nos controles AAS e PPSWR, todas as categorias ficaram próximas de 95% (tolerância de diagnóstico ±5 p.p.).
- O efeito hipotético de resposta de A reduz a cobertura observada do pseudo-IC no cenário digital.
- CSV, programa, notebooks e hashes do manifesto acompanham o pacote.

## Uso no Colab

O notebook independente e a seção integrada do Notebook 02 contêm um primeiro experimento autossuficiente. O painel dos cinco métodos lê `dados/rodadas_cobertura_por_candidato_v1_5.csv.gz` e permite trocar candidato, cenário e número de repetições exibidas. Basta colocar o arquivo no diretório `dados/` do repositório ou enviá-lo à sessão do Colab. A geração da base de 1 milhão já foi executada e não precisa ser repetida para montar os gráficos.
